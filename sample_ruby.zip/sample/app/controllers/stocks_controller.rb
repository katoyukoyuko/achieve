class StocksController < ApplicationController

  def index
  end

end
