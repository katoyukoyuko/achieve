class StopsController < ApplicationController
  def index
  end
end
