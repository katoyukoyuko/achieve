class Blog < ApplicationRecord
  validates :title, presence: true
end
